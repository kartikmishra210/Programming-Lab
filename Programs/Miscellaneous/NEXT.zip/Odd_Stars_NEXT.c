//Prints Odd Asterisks 

#include<stdio.h>

int main(){

for(i=1;i<=9;i+=2) {

printf
