//Prints Hashtag lines

#include<stdio.h>

int main(){

int i=4;

while(i)
printf("####\n"), i--;

return 0;

}
