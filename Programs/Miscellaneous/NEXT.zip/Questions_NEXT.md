
- Create the following patterns using loops :

```
####
####
####
####
```


```
*
***
*****
*******
*********
*******
*****
***
*
```

- Print the following pattern for n rows :

```
*
**
***
****
*****
```

- Print a pyramid like pattern for n rows :

```
A
A B
A B C
```

- Form a pyramid of numbers for a given num like the following :

```
	 1
	121
        12321
       1234321
```
